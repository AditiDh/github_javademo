package com.cybage.exception;

public class CheckedException {

	public static void main(String[] args) {
		
		
	}

}
