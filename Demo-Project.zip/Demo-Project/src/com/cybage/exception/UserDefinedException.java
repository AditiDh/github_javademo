package com.cybage.exception;

public class UserDefinedException extends RuntimeException {
	public UserDefinedException(String msg) {
	super(msg);
	}
	public static void main(String[] args) {
		

	}

}
