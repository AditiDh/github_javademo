package com.cybage.basic;

interface Mathoperations
{
	float PI=3.14F;
	public void add(int n1,int n2);
	public void sub(int n1,int n2);
	
	default void multiplication(int n1,int n2)
	{
		System.out.println("multiplication="+(n1*n2));
	}
	
	default void division(int n1,int n2)
	{
		System.out.println("div="+(n1/n2));
	}
	static void greet() {
		System.out.println("good morning");
	}
}


class Calculator implements Mathoperations
{
	@Override
	public void add(int n1,int n2) {
		System.out.println("sum="+(n1+n2));
	}

	@Override
	public void sub(int n1, int n2) {
		// TODO Auto-generated method stub
		System.out.println("sub="+(n1-n2));
	}
	
	@Override
	public void multiplication(int n1,int n2)
	{
		System.out.println("multiplication in subclass");
	}
	
}

public class InterfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator calculator=new Calculator();
		calculator.add(10,20);
		Mathoperations mOperations=new Calculator();
		mOperations.add(20,30);
		mOperations.sub(50,30);
		mOperations.multiplication(2, 30);
		mOperations.division(10, 2);
		System.out.println(Mathoperations.PI);
		Mathoperations.greet();

	}

}
