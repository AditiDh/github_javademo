package com.cybage.basic;

public class countObj {
	static String msg1;
	

}
