package com.cybage.basic;

interface MathFunctional
{
	public int add(int num1,int num2);
	
}

public class FunctionalExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MathFunctional addition=( num1, num2)->(num1+num2) ;
		
		System.out.println(addition.add(5, 5)) ;
		System.out.println(addition.add(4, 8)) ;
		
	
	}

}
